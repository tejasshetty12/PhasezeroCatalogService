package com.org.phasezero_catalog_service.Controller;

import com.org.phasezero_catalog_service.Service.ProductService;
import com.org.phasezero_catalog_service.model.Product;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/products")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    
    @PostMapping
    public Map<String, String> addProduct(@RequestBody Product p) {
        service.addProduct(p);
        return Map.of("message", "Product added successfully");
    }

   
    @GetMapping
    public List<Product> getAll() {
        return service.getAll();
    }

   
    @GetMapping("/search")
    public List<Product> search(@RequestParam String name) {
        return service.searchByName(name);
    }

    
    @GetMapping("/filter")
    public List<Product> filter(@RequestParam String category) {
        return service.filterByCategory(category);
    }

   
    @GetMapping("/sort/price")
    public List<Product> sortByPrice() {
        return service.sortByPrice();
    }

    
    @GetMapping("/inventory/value")
    public Map<String, Double> totalValue() {
        return Map.of("totalValue", service.totalValue());
    }
}
