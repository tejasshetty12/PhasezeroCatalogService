package com.org.phasezero_catalog_service.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ProductException.class)
    public ResponseEntity<Map<String, Object>> handleProductError(ProductException ex) {
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST) // simple and allowed
                .body(Map.of("message", ex.getMessage()));
    }
}
