package com.org.phasezero_catalog_service.exception;

public class ProductException extends RuntimeException {
    public ProductException(String message) {
        super(message);
    }
}
