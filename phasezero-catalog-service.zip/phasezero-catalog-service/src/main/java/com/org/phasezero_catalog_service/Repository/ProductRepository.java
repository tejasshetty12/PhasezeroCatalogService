package com.org.phasezero_catalog_service.Repository;

import com.org.phasezero_catalog_service.model.Product;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class ProductRepository {

    private Map<String, Product> store = new HashMap<>();

    public boolean exists(String partNumber) {
        return store.containsKey(partNumber);
    }

    public void save(Product p) {
        store.put(p.getPartNumber(), p);
    }

    public List<Product> findAll() {
        return new ArrayList<>(store.values());
    }
}
