package com.org.phasezero_catalog_service.Service;

import com.org.phasezero_catalog_service.Repository.ProductRepository;
import com.org.phasezero_catalog_service.exception.ProductException;
import com.org.phasezero_catalog_service.model.Product;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    private final ProductRepository repo;

    public ProductService(ProductRepository repo) {
        this.repo = repo;
    }

    
    public void addProduct(Product p) {

        if (repo.exists(p.getPartNumber())) {
            throw new ProductException("partNumber already exists");
        }

        if (p.getPrice() < 0) {
            throw new ProductException("price cannot be negative");
        }

        if (p.getStock() < 0) {
            throw new ProductException("stock cannot be negative");
        }

        if (p.getPartName() == null || p.getPartName().isBlank()) {
            throw new ProductException("partName is required");
        }

        
        p.setPartName(p.getPartName().toLowerCase());

        repo.save(p);
    }

   
    public List<Product> getAll() {
        return repo.findAll();
    }

    
    public List<Product> searchByName(String name) {
        return repo.findAll().stream()
                .filter(p -> p.getPartName().contains(name.toLowerCase()))
                .collect(Collectors.toList());
    }

    
    public List<Product> filterByCategory(String category) {
        return repo.findAll().stream()
                .filter(p -> p.getCategory().equalsIgnoreCase(category))
                .collect(Collectors.toList());
    }

    
    public List<Product> sortByPrice() {
        return repo.findAll().stream()
                .sorted((a, b) -> Double.compare(a.getPrice(), b.getPrice()))
                .collect(Collectors.toList());
    }

    
    public double totalValue() {
        return repo.findAll().stream()
                .mapToDouble(p -> p.getPrice() * p.getStock())
                .sum();
    }
}
